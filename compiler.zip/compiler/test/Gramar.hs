module Gramar where

type Id = String

data Tipo = TDouble | TInt | TString | TVoid
    deriving Show

data TCons = CDouble Double | CInt Integer
    deriving Show

data Expr = Expr :+: Expr | Expr :-: Expr | Expr :*: Expr | Expr :/: Expr |
            Neg Expr | Const TCons | IdVar Id | Chamada Id [Expr] | Lit String
    deriving Show

data ExprR = Expr :==: Expr | Expr :/=: Expr | Expr :<: Expr |
             Expr :>: Expr | Expr :<=: Expr | Expr :>=: Expr 
    deriving Show

data ExprL = ExprL :&: ExprL | ExprL :|: ExprL | Not ExprL | Rel ExprR
    deriving Show

data Var = Id :#: Tipo 
    deriving Show

data Funcao = Id :->: ([Var], Tipo) 
    deriving Show

data Programa = Prog [Funcao] [(Id, [Var], Bloco)] [Var] Bloco 
    deriving Show

type Bloco = [Comando]

data Comando = If ExprL Bloco Bloco
               | While ExprL Bloco
               | Atrib Id Expr
               | Leitura Id
               | Imp Expr
               | Ret (Maybe Expr)
               | Proc Id [Expr]
               deriving Show
