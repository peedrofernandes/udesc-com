module SemanticAnalyzer where

import CompilerProps

semanticAnalysis :: Programa -> Programa
semanticAnalysis = undefined

