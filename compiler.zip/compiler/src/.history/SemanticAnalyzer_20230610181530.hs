module SemanticAnalyzer where
  
import Control.Monad.Except
import Control.Monad.Identity
import Control.Monad.State
import CompilerProps

import qualified Data.Map as Map

data SymbolTable = SymbolTable
  { variables :: Map.Map Id Tipo
  , functions :: Map.Map Id ([Var], Tipo)
  } deriving (Eq, Show)

newtype SemanticError = SemanticError String deriving (Eq, Show)

type SemanticAnalyzer a = StateT SymbolTable (ExceptT SemanticError Identity) a

-- Helper functions
lookupVariable :: Id -> SemanticAnalyzer (Maybe Tipo)
lookupVariable name = do
  symbolTable <- get
  return $ Map.lookup name (variables symbolTable)

lookupFunction :: Id -> SemanticAnalyzer (Maybe ([Var], Tipo))
lookupFunction name = do
  symbolTable <- get
  return $ Map.lookup name (functions symbolTable)

insertVariable :: Id -> Tipo -> SemanticAnalyzer ()
insertVariable name t = modify (\symbolTable -> symbolTable { variables = Map.insert name t (variables symbolTable) })

insertFunction :: Id -> ([Var], Tipo) -> SemanticAnalyzer ()
insertFunction name func = modify (\symbolTable -> symbolTable { functions = Map.insert name func (functions symbolTable) })

-- -- Type coercion functions
-- coerceIntToDouble :: Expr -> Expr
-- coerceIntToDouble expr = ...

-- coerceDoubleToInt :: Expr -> Expr
-- coerceDoubleToInt expr = ...

-- -- Semantic analysis functions
-- checkExpr :: Expr -> SemanticAnalyzer Tipo
-- checkExpr expr = ...

-- checkExprL :: ExprL -> SemanticAnalyzer ()
-- checkExprL exprL = ...

-- checkComando :: Comando -> SemanticAnalyzer ()
-- checkComando (If exprL bloco1 bloco2) = do
--   checkExprL exprL
--   mapM_ checkComando bloco1
--   mapM_ checkComando bloco2
-- checkComando (While exprL bloco) = do
--   checkExprL exprL
--   mapM_ checkComando bloco
-- checkComando (Atrib id expr) = do
--   varType <- lookupVariable id
--   exprType <- checkExpr expr
