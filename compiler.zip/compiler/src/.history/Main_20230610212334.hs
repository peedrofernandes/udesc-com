module Main where

import Text.Parsec ( runParser, ParseError )
import Parser ( parserPrograma )
import CompilerProps ( Programa )

start :: String -> Either ParseError Programa
start = runParser parserPrograma [] "Expressões"

compile s = case start s of
  Left error -> print error
  Right arvoreSintatica -> putStrLn ("Compilado com sucesso - Arvore sintatica do programa: " ++ show arvoreSintatica)

main = do { code <- readFile "code/teste1.txt" 
          ; compile code }

