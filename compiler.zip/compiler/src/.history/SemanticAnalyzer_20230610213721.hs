module SemanticAnalyzer where

import Control.Monad.State
import CompilerProps

import qualified Data.Map as Map

type SymbolTable = Map.Map Id Tipo
type SymbolTableState a = State SymbolTable a

-- O analisador semântico deve receber como entrada a AST, representada pelo tipo de
-- dado algébrico Programa, fazer a verificação de tipos e retornar uma AST
-- correspondente incluindo as coerções de tipos, erros e advertências deverão ser emitidos
-- no processo. As regras para coerção de tipos e emissão de mensagens de erro são:

-- - Em expressões binárias aritméticas ou relacionais quando um dos operandos for
-- do tipo int e o outro for do tipo double o operando do tipo int deve ser
-- convertido à double.
-- ------------------------------------
-- checkExpr, checkExprR
-- checkExpr :: Expr -> Expr
-- checkExpr = 

-- - Quando uma variável declarada como double receber o valor de uma expressão
-- de tipo int, o resultado da expressão deve ser convertido para o tipo double. Isso
-- é válido para comandos de atribuição, passagem de parâmetros em chamadas de
-- funções e para o retorno de funções.
-- ------------------------------------
-- checkVar

-- - Quando uma variável declarada como int receber o valor de uma expressão de
-- tipo double, o resultado da expressão deve ser convertido para o tipo int, nesse
-- caso deve ser emitida uma mensagem de advertência. Isso é válido para
-- comandos de atribuição, passagem de parâmetros em chamadas de funções e
-- para o retorno de funções.
-- ------------------------------------

-- - O tipo string pode ocorrer apenas em expressões relacionais, os dois operandos
-- devem ser do mesmo tipo, caso contrário uma mensagem de erro deve ser
-- emitida.
-- ------------------------------------

-- - Expressões com tipos incompatíveis devem emitir mensagens de erro.
-- ------------------------------------

-- - Chamadas de funções com número de parâmetros errados ou com parâmetros
-- formais e reais com tipos conflitantes devem ocasionar a emissão de mensagens
-- de erro.
-- ------------------------------------

-- - Atribuição de variáveis ou retorno de funções com tipos conflitantes devem
-- ocasionar a emissão de mensagens de erro.
-- ------------------------------------

-- - O uso de variáveis não declaradas deve informado com uma mensagem de erro.
-- ------------------------------------

-- - Chamada de funções não declaradas deve ocasionar a emissão de uma
-- mensagem de erro.
-- ------------------------------------

-- - A existência de variáveis multiplamente declaradas em uma mesma função deve
-- ocasionar a emissão de uma mensagem de erro.
-- ------------------------------------

-- - A existência de funções multiplamente declaradas deve ocasionar uma
-- mensagem de erro.
-- ------------------------------------

-- Tipos de dados que devem ser verificados:
-- Expr (apenas binárias);
-- ExprR (apenas binárias (todas));
-- Var (int para double);
-- 

-- 

checkFuncoes :: [Funcao] -> SymbolTableState [Funcao]
checkFuncoes ((id :->: ([v], t)) : fs) = 
  do { tableState <- get
     ; case Map.lookup id tableState of 
        Just _ -> error $ "Function " ++ id ++ " is declared twice"
        Nothing -> do }

-- semanticAnalyzer :: Programa -> SymbolTableState Programa
-- semanticAnalyzer (Prog f fImpl var bloco) = do
--   let assinaturaFuncoes = checkFuncoes f
--   let 




