module SemanticAnalyzer where

import CompilerProps

semanticAnalysis :: Programa -> Programa
