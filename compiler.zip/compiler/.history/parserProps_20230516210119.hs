import Text.Parsec
import Text.Parsec.Token as T

type Id = String
data Tipo = TDouble | TInt | TString | TVoid deriving Show
data TCons = CDouble Double | CInt Int deriving Show
data Expr = Expr :+: Expr 
          | Expr :-: Expr 
          | Expr :*: Expr 
          | Expr :/: Expr
          | Neg Expr
          | Const TCons
          | IdVar Id
          | Chamada Id [Expr]
          | Lit String
          deriving Show
data ExprR = Expr :==: Expr
           | Expr :/=: Expr
           | Expr :<: Expr
           | Expr :>: Expr
           | Expr :<=: Expr
           | Expr :>=: Expr
           deriving Show
data ExprL = ExprL :&: ExprL
           | ExprL :|: ExprL
           | Not ExprL
           | Rel ExprR
           deriving Show
data Var = Id :#: Tipo deriving Show
data Funcao = Id :->: ([Var], Tipo) deriving Show
data Programa = Prog [Funcao] [(Id, [Var], Bloco)] [Var] Bloco deriving Show
type Bloco = [Comando]
data Comando = If ExprL Bloco Bloco
             | While ExprL Bloco
             | Atrib Id Expr
             | Leitura Id
             | Imp Expr
             | Ret (Maybe Expr)
             | Proc Id [Expr]
             deriving Show

-- lingdef = emptyDef {
--   T.string = "string",
--   T.double = "double",
--   T.int = "int"
-- }

langDef = emptyDef {
  T.commentStart = "/*",
  T.commentEnd = "*/",
  T.commentLine = "//",
  T.reservedNames = ["int", "double", "string", "if", "while", "print", "read"],
  T.reservedOpNames = ["+", "-", "*", "/", "&", "|", "!", "==", "!=", ">", "<", ">=", "<="]
}

lexer :: GenTokenParser s u m
lexer = T.makeTokenParser langDef

natural = T.natural lexer
symbol = T.symbol lexer
parens = T.parens lexer
braces = T.braces lexer
brackets = T.brackets lexer
reservedOp = T.reservedOp lexer
identifier = T.identifier lexer
reserved = T.reserved lexer
operator = T.operator lexer
stringLiteral = T.stringLiteral lexer
integer = T.integer lexer
float = T.float lexer
whiteSpace = T.whiteSpace lexer
semi = T.semi lexer
comma = T.comma lexer


type Parser u r = Parsec String u r